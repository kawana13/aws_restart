print("Python has three numeric types: int, float, and complex")

myvalue = 1
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))

myvalue = 3.14
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))

myvalue = 5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))

myvalue = True
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))

myvalue = False
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is of the data type " + str(type(myvalue)))